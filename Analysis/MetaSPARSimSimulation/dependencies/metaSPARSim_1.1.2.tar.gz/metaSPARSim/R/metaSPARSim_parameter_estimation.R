# Estimate the intensity values for the OTUs in the OTU table
# param:
#   - data: normalized OTU table (OTUs on rows, samples on columns) for one samples group (i.e. body site, geographic location, niche, ...)
#           rownames(data) must contain OTU names
#   - aggregate_func: if "mean", the intensity is computed as mean of normalized counts for each OTU
#                     if "median" the intensity is computed as median of the normalized counts for each OTU
#                     if "max" the intensity is computed as maximum of the normalized counts for each OTU
#   - keep_zeros: if TRUE (default), zeros are included in the computation of OTU intensity using the function specified in "aggregate_func"
#                 if FALSE, zeros are not inclueded in the computation of OTU intensity using the function specified in "aggregate_func" (e.g. mean of not zeros values)
# return:
#   an array of intensity values having N_OTUs elements (N_OTUs = nrow(data))
estimate_intensity <-
  function(data,
           aggregate_func = "mean",
           keep_zeros = TRUE) {
    aggregate_func <- match.arg(aggregate_func, c("mean", "median", "max"))
    N_OTUs <- nrow(data)
    stopifnot(N_OTUs >= 1)
    intensity_val <- array(0, dim = N_OTUs)
    names(intensity_val) <- rownames(data)

    # intensity as maximum of normalized counts
    if (aggregate_func == "max") {
      intensity_val <- apply(data, 1, max)
    }

    # intensity as mean of normalized counts
    if (aggregate_func == "mean") {
      if (keep_zeros == TRUE) {
        intensity_val <- apply(data, 1, mean)
      } else{
        for (i in 1:N_OTUs) {
          if (sum(data[i, ] > 0)) {
            intensity_val[i] <- mean(data[i, data[i, ] > 0])
          }
        }
      }

    }

    # intensity as median of normalized counts
    if (aggregate_func == "median") {
      if (keep_zeros == TRUE) {
        intensity_val <- apply(data, 1, median)
      }
      else{
        for (i in 1:N_OTUs) {
          if (sum(data[i, ] > 0)) {
            intensity_val[i] <- median(data[i, data[i, ] > 0])
          }
        }
      }

    }

    return (intensity_val)

  }



# Estimate the variability values for the OTUs in the OTU table
# param:
#   - data: OTU table (OTUs on rows, samples on columns) for one samples group (i.e. body site, geographic location, niche, ...)
#           depending on "variability_func" parameters, the OTU table should be normalized or not
#   - variability_func: if "dispersion" (default) the variability is computed as edgeR tagwise dispersion of the OTUs in "data" (data should be a RAW OTU table, i.e. NOT NORMALIZED). If "variance", the count variance is computed and a NORMALIZED count table shoud be given as input; PLEASE USE IT ONLY FOR DIAGNOSTIC PURPOSES.
#   - perc_not_zeros: range [0,1]; variability are computed only for OTUs having more than "perc_not_zeros" percentage of values greater than zeros, variabilty of the remaining OTU would be set to NA
# return: array of variability values having N_OTUs elements (N_OTUs = nrow(data))

#' import
estimate_variability <-
  function (data,
            variability_func = "dispersion",
            perc_not_zeros = 0.2) {
    variability <- array(NA, dim = nrow(data))

    # variability as edgeR dispersion of RAW counts in data
    if (variability_func == "dispersion") {
      # compute percentage of entry > 0 for each OTU
      perc_not_zeros_per_OTU <- rowSums(data > 0) / ncol(data)

      # Indices of OTUs passing the filter
      ind_pass_filter <- (perc_not_zeros_per_OTU > perc_not_zeros)

      # number of OTUs passing the filter
      N_OTU_pass_filter <- sum(ind_pass_filter)
      message(
        N_OTU_pass_filter,
        " OTUs have values >0 in more than ",
        perc_not_zeros * 100,
        "% of samples"
      )

      if (N_OTU_pass_filter > 1) {
        f <- edgeR::DGEList(as.matrix(data[ind_pass_filter, ]))
        f <- edgeR::estimateGLMCommonDisp(f)
        f <- edgeR::estimateGLMTrendedDisp(f)
        f <- edgeR::estimateGLMTagwiseDisp(f)

        variability[ind_pass_filter] <- f$tagwise.dispersion
      }
    }

    # variability as variance of NORMALIZED counts in data
    if (variability_func == "variance") {
        variability<- apply(data, 1, var)
    }
    return(variability)

  }


# estimate the library sizes for the samples in the OTU table
# param:
#   - data: OTU table (OTU on rows, samples on columns) for one samples group (i.e. body site, geographic location, niche, ...)
# return: array of library size values having N_samples elements (N_samples = ncol(data))
estimate_library_size <- function (data) {
  return(colSums(data))
}

#'estimate_parameter_from_data
#'
#' Estimate the parameters (intesity, variability and library sizes) for each samples group
#'
#' @param raw_data OTU table (OTU on rows, samples on columns) containing raw data
#' @param norm_data OTU table (OTU on rows, samples on columns) containing normalized data
#' @param conditions list; the i-th element of the list contains the column indices for i-th samples group. List must be a named list.
#' @param intensity_func
#'   if "mean", the intensity is computed as mean of normalized counts (norm_data) for each OTU
#'   if "median" the intensity is computed as median of the normalized counts (norm_data) for each OTU
#'   if "max" the intensity is computed as maximum of the normalized counts (norm_data) for each OTU
#' @param keep_zeros
#'     if TRUE (default), zeros are included in the computation of OTUs intensity using the function specified in "intesity_func"
#'     if FALSE, zeros are not inclueded in the computation of OTUs intensity using the function specified in "intensity_func" (e.g. mean of not zeros values)
#' @param perc_not_zeros: range [0,1]; variability are computed only for OTUs having at least "perc_not_zeros" values greater than zeros, variabilty of the remaining OTU would be set to NA
#' @export
estimate_parameter_from_data <-
  function (raw_data,
            norm_data,
            conditions,
            intensity_func = "mean",
            keep_zeros = TRUE,
            perc_not_zeros = 0.2) {
    # Number of samples group
    N_cond <- length(conditions)

    # Number of OTUs
    N_feature <- nrow(raw_data)

    dataset_parameter <- list()
    if (any(lengths(conditions) <= 1)) {
      stop("The conditions should have at least two samples per group.")
    }

    cond_i <- 1
    for (cond in conditions) {
      cond_parameter <- list()
      # estimate intesity
      cond_parameter$intensity <-
        estimate_intensity (data = norm_data[, cond, drop = FALSE],
                            aggregate_func = intensity_func,
                            keep_zeros = keep_zeros)

      # estimate variability
      cond_parameter$variability <-
        estimate_variability (
          data = raw_data[, cond, drop = FALSE],
          variability_func = "dispersion",
          perc_not_zeros = perc_not_zeros
        )

      # estimate library size
      cond_parameter$lib_size <-
        estimate_library_size(data = raw_data[, cond, drop = FALSE])

      dataset_parameter[[cond_i]] <- cond_parameter
      cond_i <- cond_i + 1

    }


    names(dataset_parameter) <- names(conditions)

    return(dataset_parameter)
  }
