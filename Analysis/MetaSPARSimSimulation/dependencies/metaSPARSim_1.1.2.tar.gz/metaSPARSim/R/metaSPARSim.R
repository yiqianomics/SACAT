#'metaSPARSim
#'
#'Function to simulate a OTU table
#'
#'@param dataset_parameters list containing, the OTUs intensity, OTUs variability and library sizes of each samples group. It is the return value of "estimate_parameter_from_data" or could be created by the users
#' return: a list of 3 elements
#'   - counts: the simulated OTU table, having OTUs on rows and samples on columns
#'   - gamma: matrix describing the species abundances across samples, having OTUs on rows and samples on columns
#'   - params: a copy of the input parameter "dataset_parameters"
#'@export
metaSPARSim <- function(dataset_parameters) {
  # number of samples groups
  N_cond <- length(dataset_parameters)
  # check if, for each condition and among conditions, the intensity and variability vectors have the same length; if so,
  # set the features names to (Feature_1, ..., Feature_nFEATURES), where nFEATURES=length(dataset_parameters[[1]]$intensity).
  nFEATURES<-length(dataset_parameters[[1]]$intensity)
  for (cond in 1:N_cond){
  	  if((length(dataset_parameters[[cond]]$intensity)!=nFEATURES) | (length(dataset_parameters[[cond]]$variability)!=nFEATURES)){
  	  	stop("Please check your input parameters: intensity and variability vectors must have the same length and the length must be the same for all the experimental conditions")
  	} else {
  		names(dataset_parameters[[cond]]$intensity)<-names(dataset_parameters[[cond]]$variability)<-paste0("Feature_",seq(1:nFEATURES))
  	}
  }

  # relation between the number of fragment given as input of the sequencing process and the number of sequenced reads
  # order of magnitude (input fragment) = order of magnitude (max (lib size) * input_fragment_scale)
  input_fragment_scale = 10 ^ 2

  # identify the maximum library size
  max_lib_size <- 0
  for (cond in 1:N_cond) {
    max_lib_size <-
      max(max_lib_size, max(dataset_parameters[[cond]]$lib_size))
  }

  # set the input fragment library size (the population size parameter for MH distribution)
  input_fragment_lib_size <- max_lib_size * input_fragment_scale
  digits <- floor(log10(input_fragment_lib_size)) + 1
  new_libsize <- 10 ^ digits


  gamma_list <- list()
  gamma_scaled_list <- list()
  mh_list <- list()

  # for each samples group
  for (cond in 1:N_cond) {
    print(paste0("Simulating samples group ", cond, " of ", N_cond))

    # number of samples (biological replicates) in the current samples group
    N_rep <- length(dataset_parameters[[cond]]$lib_size)

    col_names <-
      paste0(names(dataset_parameters)[cond], "_R", c(1:N_rep))

    frag_scale <- NULL


    ### simulate biological variability
    print("\t\t Simulating biological variability")

    gamma_list[[cond]] <-
      simulate_biovar(
        avgAbund = dataset_parameters[[cond]]$intensity,
        phi = dataset_parameters[[cond]]$variability,
        nrep = N_rep,
        frag_scale = frag_scale
      )

    ### rescale gamma and set the colsums

    # rescale values to the power of ten that is the nearest to the higher sequencing depth obtained
    gamma_scaled_list[[cond]] <-
      simulate_rescaling (abund_matrix = gamma_list[[cond]], new_libsize = new_libsize)

    ### simulate sequencing
    print("\t\t Simulating sequencing process")
    mh_list[[cond]] <- gamma_list[[cond]]

    for (rep in 1:N_rep) {
      mh_list[[cond]][, rep] <-
        simulate_hyper(
          avgAbund = gamma_scaled_list[[cond]][, rep],
          seqdepth = dataset_parameters[[cond]]$lib_size[rep],
          digits = digits
        )
    }

    colnames(mh_list[[cond]]) <- col_names
    colnames(gamma_scaled_list[[cond]]) <- col_names
    colnames(gamma_list[[cond]]) <- col_names

  }

  # create the final OTU table concatenating the single OTU tables of each samples group
  count_matrix <- concatenate_matrix(mh_list)

  # create the global species abundance matrix concatenating the single species abundance matrices of each samples group
  gamma_matrix <-
    concatenate_matrix(gamma_scaled_list)

  return(list(
    counts = count_matrix,
    gamma = gamma_matrix,
    params = dataset_parameters
  ))
}
