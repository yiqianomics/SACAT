# metaSPARSim

metaSPARSim is an R tool for 16S rRNA-gene sequencing count data simulation.

To cite this package please use _**"metaSPARSim: a 16S rRNA gene sequencing count data simulator", Ilaria Patuzzi, Giacomo Baruzzo, Carmen Losasso, Antonia Ricci, Barbara Di Camillo. 
BMC Bioinformatics, 20 (Suppl 9), 416 (2019),**_
 [https://doi.org/10.1186/s12859-019-2882-6](https://doi.org/10.1186/s12859-019-2882-6)




## Applications of metaSPARSim in scientific research

metaSPARSim has been widely adopted by the research community for benchmarking and evaluating microbiome data analysis tools. 
Below is a non-exhaustive list of peer-reviewed publications that have utilized metaSPARSim in various contexts:

- **metaSPARSim** abudance modelling was used in MHASS, a read simulator for PacBio HiFi amplicon sequencing. [_“MHASS: Microbiome HiFi Amplicon Sequencing Simulator”_, **Bioinformatics**, 2026](https://doi.org/10.1093/bioinformatics/btaf656)
- **metaSPARSim**-simulated data were used in a benchmarking framework to compare 22 differential abundance methods for 16S data. [_“ Benchmarking Differential Abundance Tests for 16S microbiome sequencing data using simulated data based on experimental templates”_, **PLOS ONE**, 2025](https://doi.org/10.1371/journal.pone.0321452)
- **metaSPARSim** was also included in a detailed review of microbiome data simulation tools. [_“Semisynthetic simulation for microbiome data analysis”_, **Briefings in Bioinformatics**, 2025](https://doi.org/10.1093/bib/bbaf051)
- **metaSPARSim** data were employed to evaluate the performance of IMPACT, a deep learning model offering accurate and interpretable classification of microbial data. [_“IMPACT: interpretable microbial phenotype analysis via microbial characteristic traits”_, **Bioinformatics**, 2025](https://doi.org/10.1093/bioinformatics/btae702)
- **metaSPARSim** was featured in a comprehensive review of high-throughput sequencing data simulators. [_“Simulated High Throughput Sequencing Datasets: A Crucial Tool for Validating Bioinformatic Pathogen Detection Pipelines”_, **Biology**, 2025](https://doi.org/10.3390/biology13090700)
- **metaSPARSim**-simulated data were used to evaluate the performance of llperm, a novel permutation of regressor residuals test for enhanced differential abundance analysis of microbiome data. [_“llperm: a permutation of regressor residuals test for microbiome data”_, **BMC Bioinformatics**, 2022](https://doi.org/10.1186/s12859-022-05088-w)
- **metaSPARSim** data were used in a benchmark of nine differential abundance methods for 16S data. [_“Investigating differential abundance methods in microbiome data: A benchmark study”_, **PLOS Computational Biology**, 2022](https://doi.org/10.1371/journal.pcbi.1010467)
- **metaSPARSim**-generated data were used to benchmark 36 preprocessing pipelines (count normalization and zero-imputation) for 16S rRNA data. [_“Beware to ignore the rare: how imputing zero-values can improve the quality of 16S rRNA gene studies results”_, **BMC Bioinformatics**, 2022](https://doi.org/10.1186/s12859-022-04587-0)
- **metaSPARSim**-simulated data were used in a benchmark of eight differential abundance methods for microbial taxa. [_“Analysing microbiome intervention design studies: Comparison of alternative multivariate statistical methods”_, **PLOS ONE**, 2021](https://doi.org/10.1371/journal.pone.0259973)



## Installation

#### Installation from GitLab

metaSPARSim is available on GitLab at https://gitlab.com/sysbiobig/metaSPARSim

To install metaSPARSim from GitLab, please use the following commands:
```r
library(devtools)
install_gitlab("sysbiobig/metaSPARSim", build_opts = c("--no-resave-data", "--no-manual"), build_vignettes = TRUE)
```
The above commands would install metaSPARSim, the required dependencies and metaSPARSim vignette. 

To install metaSPARSim without the vignette, please use the following commands:
```r
library(devtools)
install_gitlab("sysbiobig/metaSPARSim")
```



#### Installation from source package

metaSPARSim R package can be downloaded at http://sysbiobig.dei.unipd.it/?q=metaSPARSim

It requires *RCpp*, *scran* and *edgeR* packages to work.

To install it from source, please use the following command:
```r
install.packages("metaSPARSim_X.X.X.tar.gz", repos = NULL, type = "source")
```
where "X.X.X" indicates the package version.

## Getting started

Please browse metaSPARSim vignette using the following commands:

```r
library(metaSPARSim)
browseVignettes("metaSPARSim")
```
