\name{estimate_library_size}
\alias{estimate_library_size}
%- Also NEED an '\alias' for EACH other topic documented here.
\title{Library size estimation
%%  ~~function to do ... ~~
}
\description{
Function to estimate the library size of samples from real data.
}
\usage{
estimate_library_size(data)
}
%- maybe also 'usage' for other objects documented here.
\arguments{
  \item{data}{
Feature table (features on rows, samples on columns).
}
}
\details{
%%  ~~ If necessary, more details than the description above ~~
}
\value{
%%  ~Describe the value returned
%%  If it is a LIST, use
\item{val }{An array of library size values having ncol(data) elements.}
%%  \item{comp2 }{Description of 'comp2'}
%% ...
}
\references{
%% ~put references to the literature/web site here ~
}
\author{
%%  ~~who you are~~
}
\note{
%%  ~~further notes~~
}

%% ~Make other sections like Warning with \section{Warning }{....} ~

\seealso{
%% ~~objects to See Also as \code{\link{help}}, ~~~
}
\examples{
data(HMP)
# Estimate library sizes from data for HMP dataset:
libsize <- estimate_library_size (data = data)
libsize

}
% Add one or more standard keywords, see file 'KEYWORDS' in the
% R documentation directory.
\keyword{ ~library }% use one of  RShowDoc("KEYWORDS")
\keyword{ ~size }% __ONLY ONE__ keyword per line
