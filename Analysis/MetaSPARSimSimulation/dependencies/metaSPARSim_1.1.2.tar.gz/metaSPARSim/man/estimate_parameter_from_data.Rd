\name{estimate_parameter_from_data}
\alias{estimate_parameter_from_data}
%- Also NEED an '\alias' for EACH other topic documented here.
\title{Parameter estimation from real data
%%  ~~function to do ... ~~
}
\description{
%%  ~~ A concise (1-5 lines) description of what the function does. ~~
}
\usage{
estimate_parameter_from_data(raw_data, norm_data, conditions,
intensity_func = "mean", keep_zeros = TRUE, perc_not_zeros = 0.2)
}
%- maybe also 'usage' for other objects documented here.
\arguments{

  \item{raw_data}{
Raw feature table (features on rows, samples on columns).
}
  \item{norm_data}{
Normalized feature table (features on rows, samples on columns).
}
  \item{conditions}{
list; the i-th element of the list contains the column indices for i-th samples group. List must be a named list.
}

  \item{intensity_func}{
If "mean", the intensity is computed as mean of normalized counts for each feaure (OTU); if "median", the intensity is computed as median of the normalized counts for each feature; if "max", the intensity is computed as maximum of the normalized counts for each feature
}

  \item{keep_zeros}{
If TRUE (default), zeros are included in the computation of feature intensity using the function specified in "aggregate_func"; if FALSE, zeros are not inclueded in the computation of feature intensity using the function specified in "aggregate_func" (e.g. mean of non-zero values)
}

  \item{perc_not_zeros}{
Number in [0,1]; variability is computed only for features having more than "perc_not_zeros" percentage of values greater than zeros; variabilty of the remaining features would be set to NA.
}
}
\details{
%%  ~~ If necessary, more details than the description above ~~
}
\value{
%%  ~Describe the value returned
%%  If it is a LIST, use
%%  \item{comp1 }{Description of 'comp1'}
%%  \item{comp2 }{Description of 'comp2'}
%% ...
}
\references{
%% ~put references to the literature/web site here ~
}
\author{
%%  ~~who you are~~
}
\note{
%%  ~~further notes~~
}

%% ~Make other sections like Warning with \section{Warning }{....} ~

\seealso{
%% ~~objects to See Also as \code{\link{help}}, ~~~
}
\examples{
data(HMP)
# Estimate parameters from real data:
params<-estimate_parameter_from_data(data, data_norm, indpop,perc_not_zeros=.2)
str(params)
}
% Add one or more standard keywords, see file 'KEYWORDS' in the
% R documentation directory.
\keyword{ ~kwd1 }% use one of  RShowDoc("KEYWORDS")
\keyword{ ~kwd2 }% __ONLY ONE__ keyword per line
