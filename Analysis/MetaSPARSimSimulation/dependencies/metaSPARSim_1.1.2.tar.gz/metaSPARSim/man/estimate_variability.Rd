\name{estimate_variability}
\alias{estimate_variability}
%- Also NEED an '\alias' for EACH other topic documented here.
\title{Count variabity estimation
%%  ~~function to do ... ~~
}
\description{
%%  ~~ A concise (1-5 lines) description of what the function does. ~~
}
\usage{
estimate_variability(data, variability_func = "dispersion", perc_not_zeros = 0.2)
}
%- maybe also 'usage' for other objects documented here.

\arguments{
  \item{data}{
Feature table (features (OTUs) on rows, samples on columns) for one samples group (i.e. body site, geographic location, niche, ...). Depending on "variability_func" parameters, the feature table should be normalized (variability_func=="variance" or "relative_variance") or not (variability_func=="dispersion").
}
  \item{variability_func}{
If "dispersion" (default) is set, the variability is computed as edgeR tagwise dispersion (see edgeR package) of the features in "data" (data should be a RAW OTU table, i.e. NOT NORMALIZED data). If "variance" is set, the count variance is computed and a NORMALIZED count table shoud be given as input; PLEASE USE IT ONLY FOR DIAGNOSTIC PURPOSES.
}
  \item{perc_not_zeros}{
Number in [0,1]; variability is computed only for features having more than "perc_not_zeros" percentage of values greater than zeros; variabilty of the remaining features would be set to NA.

}
}
\details{
%%  ~~ If necessary, more details than the description above ~~
}
\value{
  \item{variability }{
An array of variability values having nrow(data) elements.
}
%%  ~Describe the value returned
%%  If it is a LIST, use
%%  \item{comp1 }{Description of 'comp1'}
%%  \item{comp2 }{Description of 'comp2'}
%% ...
}
\references{
%% ~put references to the literature/web site here ~
}
\author{
%%  ~~who you are~~
}
\note{
%%  ~~further notes~~
}

%% ~Make other sections like Warning with \section{Warning }{....} ~

\seealso{
%% ~~objects to See Also as \code{\link{help}}, ~~~
}
\examples{
library(metaSPARSim)
data(HMP)
# Estimate count variance from data for samples belonging to the first experimental condition:
variability <- estimate_variability (data = data_norm[,indpop[[1]]],
variability_func = "variance")
variability

}
% Add one or more standard keywords, see file 'KEYWORDS' in the
% R documentation directory.
\keyword{ ~kwd1 }% use one of  RShowDoc("KEYWORDS")
\keyword{ ~kwd2 }% __ONLY ONE__ keyword per line
