\name{estimate_intensity}
\alias{estimate_intensity}
%- Also NEED an '\alias' for EACH other topic documented here.
\title{Count intensity estimation
%%  ~~function to do ... ~~
}
\description{
%%  ~~ A concise (1-5 lines) description of what the function does. ~~
Function to estimate the intensity of count values from real data.
}
\usage{
estimate_intensity(data, aggregate_func = "mean", keep_zeros = TRUE)
}
%- maybe also 'usage' for other objects documented here.
\arguments{
  \item{data}{
Normalized feature table (features on rows, samples on columns) for one samples group (i.e. body site, geographic location, niche, ...). rownames(data) must contain feature names
}
  \item{aggregate_func}{
If "mean", the intensity is computed as mean of normalized counts for each feaure (OTU); if "median", the intensity is computed as median of the normalized counts for each feature; if "max", the intensity is computed as maximum of the normalized counts for each feature
}
  \item{keep_zeros}{
If TRUE (default), zeros are included in the computation of feature intensity using the function specified in "aggregate_func"; if FALSE, zeros are not inclueded in the computation of feature intensity using the function specified in "aggregate_func" (e.g. mean of non-zero values)
}
}
\details{
%%  ~~ If necessary, more details than the description above ~~
}
\value{
%%  ~Describe the value returned
%%  If it is a LIST, use
  \item{intensity_val }{
An array of intensity values having nrow(data) elements.
}
%%  \item{comp2 }{Description of 'comp2'}
%% ...
}
\references{
%% ~put references to the literature/web site here ~
}
\author{
%%  ~~who you are~~
}
\note{
%%  ~~further notes~~
}

%% ~Make other sections like Warning with \section{Warning }{....} ~

\seealso{
%% ~~objects to See Also as \code{\link{help}}, ~~~
}
\examples{
data(HMP)
# Estimate mean count intensity from data for samples belonging to the first experimental condition:
intensity <- estimate_intensity (data = data_norm[,indpop[[1]]],
aggregate_func = "mean", keep_zeros = TRUE)
intensity

}
% Add one or more standard keywords, see file 'KEYWORDS' in the
% R documentation directory.
\keyword{ ~intensity }

